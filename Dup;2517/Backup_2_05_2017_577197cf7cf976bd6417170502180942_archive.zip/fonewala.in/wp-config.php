<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'a365ocke_wp51');

/** MySQL database username */
define('DB_USER', 'a365ocke_wp51');

/** MySQL database password */
define('DB_PASSWORD', 'G8S@dhp]42');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'xavea3b9pqjbyu3w2fcgfiqgvhuayqdjciqbwjfzvzveqadrte4ef6yiitwahsor');
define('SECURE_AUTH_KEY',  'o7clxyntktr89gd7iukad2gjqvx9pwqonvop4vxgbygohhnv8lpohxrgguzjwnlx');
define('LOGGED_IN_KEY',    '2yig0yk85mmwbd2ohxfbv7t7nd8qsmjtu4yrvh9u82lw3ea8ypzmyomrqw5uvaxx');
define('NONCE_KEY',        'onbxx9ebuzflsnpnjhy4wwzqcb269qchrggwfo1nlwnynltlludzoymhvl5m7had');
define('AUTH_SALT',        'ue9wruubrd1lvhy8v86vgfagpsficxkb1palccfyuh0yycvatm0vnay0y5qvanld');
define('SECURE_AUTH_SALT', 'hagwisiuqxgrjbcutlqcwhjqtph4mfvf7n1cuwxjkn3dgj0gq2nooqy18hv4goel');
define('LOGGED_IN_SALT',   'pmri6hyqhhuhomqbzdngunajftdkvuh6nfn1d7gp7okmy1eielkbam6t5dstlsip');
define('NONCE_SALT',       'knw1wonmp5qs8xqh9orgwxvwdeviyzdwu0idtoifmjbpri8ftlukk9pnxqeims85');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wpnq_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
